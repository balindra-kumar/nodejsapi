const mongoose = require("mongoose");
const userSchema = new mongoose.Schema({
    username:String,
    emailid: String,
    dob: String,
    city: String
})

const userModel = mongoose.model("registration",userSchema);

module.exports = userModel;
