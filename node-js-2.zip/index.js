

// server.js
const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const server = http.createServer((req, res) => {
    // Parse the request URL
    const parsedUrl = url.parse(req.url, true);

    // Get the path from the URL
    
    let pathname = parsedUrl.pathname;
    if (pathname === '/') {
        pathname = '/home';
    }


// Check if the request is for an image file
if (pathname.startsWith('/assets/img/')) {
    const imagePath = path.join(__dirname, pathname);

    // Read the image file and serve it
    fs.readFile(imagePath, (err, imageData) => {
        if (err) {
            // If file not found, return a 404 response
            res.writeHead(404, { 'Content-Type': 'text/html' });
            return res.end('404 Not Found');
        }

        // Determine the content type based on the file extension
        const ext = path.extname(imagePath).toLowerCase();
        const contentType = {
            '.jpg': 'image/jpeg',
            '.jpeg': 'image/jpeg',
            '.png': 'image/png',
            '.gif': 'image/gif',
            '.ico': 'image/x-icon',
        }[ext] || 'application/octet-stream';

        // Return the image content
        res.writeHead(200, { 'Content-Type': contentType });
        res.write(imageData);
        res.end();
    });
}


else{





    // Map the requested path to the corresponding HTML file
   
     filePath= path.join(__dirname, `${pathname}.html`);
     
    // Read the HTML file
    fs.readFile(filePath, (err, data) => {
        if (err) {
            // If file not found, return a 404 response
            res.writeHead(404, {'Content-Type': 'text/html'});
            return res.end('404 Not Found');
        }
       const header=fs.readFileSync(path.join(__dirname,'header.html'),'utf-8');
       const footer=fs.readFileSync(path.join(__dirname,'footer.html'),'utf-8');

       const fullpage = header+data+footer;
        // Return the HTML content
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(
            fullpage
        );
        res.end();
    });
}
});

const port = 3000;

// Start the server
server.listen(port, () => {
    console.log(`Server is running at http://localhost:${port}`);
});